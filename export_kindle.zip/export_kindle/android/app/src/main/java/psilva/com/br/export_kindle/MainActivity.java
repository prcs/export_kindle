package psilva.com.br.export_kindle;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.io.File;

import io.flutter.app.FlutterActivity;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;
  import android.support.v4.content.FileProvider;

public class MainActivity extends FlutterActivity {

  private String sharedText;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    GeneratedPluginRegistrant.registerWith(this);

    Intent intent = getIntent();
    String action = intent.getAction();
    String type = intent.getType();

    if (Intent.ACTION_SEND.equals(action) && type != null) {
      if ("text/plain".equals(type)) {
        handleSendText(intent); // Handle text being sent
      }
    }

    new MethodChannel(getFlutterView(), "app.channel.shared.data").setMethodCallHandler(
            new MethodChannel.MethodCallHandler() {
              @Override
              public void onMethodCall(MethodCall call, MethodChannel.Result result) {
                if (call.method.contentEquals("getSharedText")) {
                  result.success(sharedText);
                  sharedText = null;
                }
              }
            });

    new MethodChannel(getFlutterView(), "team.native.io/screenshot").setMethodCallHandler(
            new MethodChannel.MethodCallHandler() {
              @Override
              public void onMethodCall(MethodCall call, MethodChannel.Result result) {
                if (call.method.equals("takeScreenshot")) {
                  String fileUri =call.argument("filePath").toString();

                  Uri imageUri = FileProvider.getUriForFile(
                          MainActivity.this,
                          "com.example.homefolder.example.provider", //(use your app signature + ".provider" )
                          fileUri);
                  sendMail(Uri.fromFile(imageUri));
                  result.success("Done");
                }
              }
            });
  }

  private void sendMail(Uri filePath){
    Intent intent = new Intent(Intent.ACTION_SEND);
    intent.setType("text/plain");
    intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"peterson_@live.com"});
    intent.putExtra(Intent.EXTRA_SUBJECT, "subject here");
    //Uri uri =Uri.parse(filePath);
    intent.putExtra(Intent.EXTRA_STREAM, filePath);
    startActivity(Intent.createChooser(intent, "Send email..."));
  }

  void handleSendText(Intent intent) {
    sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
  }
}
